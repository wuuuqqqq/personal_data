#!/bin/bash


rm -rf *cf
echo -e "\033[32m 请选择CF 账号: 1   2   3   4   9    10 \033[0m"

read -p "请输入您选择的CF账号:" cad

if [ $cad -eq 1 ];
   then source env/1.env;
elif [ $cad -eq 2 ];
   then source env/2.env; 
elif [ $cad -eq 3 ];
   then source env/3.env;
elif [ $cad -eq 4 ];
   then source env/4.env;
elif [ $cad -eq 5 ];
   then source env/5.env;
elif [ $cad -eq 6 ];
   then source env/6.env;
elif [ $cad -eq 9 ];
   then source env/9.env;
elif [ $cad -eq 10 ];
   then source env/10.env;
else
  echo "输入错误，退出程序" 
  exit 1
fi


# 新增域名
for domain in $(cat $PWD/domains.txt)
do
    curl -X POST -H "X-Auth-Key: ${CF_API_KEY}" \
    -H "X-Auth-Email: ${CF_API_EMAIL}" \
    -H "Content-Type: application/json" "https://api.cloudflare.com/client/v4/zones" \
     --data '{"name":"'"${domain}"'","jump_start":true,"organization":{"name":"'"${organization_name}"'","id":"'"${organization_id}"'"}}' >> $PWD/get_zone_id.cf
    ${ECHO} -e "\n" >> $PWD/get_zone_id.cf
done


# 执行python脚本，过滤出域名的区域ID
$PYTHON $PWD/deletes.py
#$PYTHON $PWD/filter_zone_id.py
