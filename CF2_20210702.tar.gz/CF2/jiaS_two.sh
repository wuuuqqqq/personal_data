#!/bin/bash

echo -e "\033[32m 请选择CF 账号: 1   2   3   4\033[0m"

read -p "请输入您选择的CF账号:" cad
if [ $cad -eq 1 ];
   then source env/1.env;
elif [ $cad -eq 2 ];
   then source env/2.env; 
elif [ $cad -eq 3 ];
   then source env/3.env;
elif [ $cad -eq 4 ];
   then source env/4.env;
else
  echo "输入错误，退出程序" 
  exit 1
fi

# 获取DNS ID列表
while read line
do
    ZONE_NAME=$(${ECHO} "$line" | awk '{print $1}')
    ZONE_ID=$(${ECHO} "$line" | awk '{print $2}')
    curl -X GET "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
         -H "X-Auth-Email: ${CF_API_EMAIL}" -H "X-Auth-Key: ${CF_API_KEY}" \
         -H "Content-Type: application/json" >> $PWD/get_dns_id.cf
    ${ECHO} -e "\n" >> $PWD/get_dns_id.cf
done < $PWD/zone_id.cf



#  执行python脚本，过滤出DNS_ID
$PYTHON $PWD/filter_dns_id.py










## 始终使用HTTPS设置
## value:off 关闭 on 开启

while read line
do
    ZONE_NAME=$(${ECHO} "$line" | awk '{print $1}')
    ZONE_ID=$(${ECHO} "$line" | awk '{print $2}')
    curl -X PATCH "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/settings/always_use_https" \
         -H "X-Auth-Email:${CF_API_EMAIL}" \
         -H "X-Auth-Key:${CF_API_KEY}" \
         -H "Content-Type:application/json" \
         --data '{"id":"always_use_https","value":"off"}'
done < $PWD/zone_id.cf
