#!/bin/bash

echo -e "\033[32m 请选择CF 账号: 1   2   3   4    9    10\033[0m"

read -p "请输入您选择的CF账号:" cad
if [ $cad -eq 1 ];
   then source env/1.env;
elif [ $cad -eq 2 ];
   then source env/2.env; 
elif [ $cad -eq 3 ];
   then source env/3.env;
elif [ $cad -eq 4 ];
   then source env/4.env;
elif [ $cad -eq 5 ];
   then source env/5.env;
elif [ $cad -eq 6 ];
   then source env/6.env;
elif [ $cad -eq 9 ];
   then source env/9.env;
elif [ $cad -eq 10 ];
   then source env/10.env;
else
  echo "输入错误，退出程序" 
  exit 1
fi


# 获取DNS ID列表
while read line
do
    ZONE_NAME=$(${ECHO} "$line" | awk '{print $1}')
    ZONE_ID=$(${ECHO} "$line" | awk '{print $2}')
#    curl -X GET "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
#         -H "X-Auth-Email: ${CF_API_EMAIL}" -H "X-Auth-Key: ${CF_API_KEY}" \
#         -H "Content-Type: application/json" >> $PWD/get_dns_id.cf
     curl -X GET "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
         -H "X-Auth-Email: ${CF_API_EMAIL}" -H "X-Auth-Key: ${CF_API_KEY}" \
         -H "Content-Type: application/json" >> $PWD/get_dns_id.cf

     ${ECHO} -e "\n" >> $PWD/get_dns_id.cf
done < $PWD/zone_id.cf





#  执行python脚本，过滤出DNS_ID
$PYTHON $PWD/filter_dns_id.py



# 删除DNS记录
# 删除DNS记录还需要指定区域ID，每个域名的区域DI不同，所以进行一个判断，判断DNS_NAME是否模糊匹配之前取到的ZONE_NAME
# 如果匹配则使用这个ZONE_ID
while read zone
do
    ZONE_NAME=$(${ECHO} "$zone" | awk '{print $1}')
    ZONE_ID=$(${ECHO} "$zone" | awk '{print $2}')
    while read dns
    do
        DNS_NAME=$(${ECHO} "$dns" | awk '{ print $1 }')
        DNS_ID=$(${ECHO} "$dns" | awk '{ print $2 }')
        if [[ "*$DNS_NAME" =~ "$ZONE_NAME" ]]
	#if [[ "$DNS_NAME" == "$ZONE_NAME" ]]
        then
            curl -X DELETE "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records/${DNS_ID}" \
                 -H "X-Auth-Email:${CF_API_EMAIL}" \
                 -H "X-Auth-Key:${CF_API_KEY}" \
                 -H "Content-Type:application/json"
        fi
    done < $PWD/dns_id.cf
done < $PWD/zone_id.cf


# 增加DNS记录
# TTL=1 为自动
# proxied=true 使用CF的CDN,等于false是不使用
# data传入变量格式： "'"$EVN"'"
# 设置变量

while read line
do
    ZONE_NAME=$(${ECHO} "$line" | awk '{print $1}')
    ZONE_ID=$(${ECHO} "$line" | awk '{print $2}') 
    curl -X POST "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
         -H "X-Auth-Email:${CF_API_EMAIL}" \
         -H "X-Auth-Key:${CF_API_KEY}" \
         -H "Content-Type:application/json" \
         --data '{"type":"A","name":"@","content":"'"${CONTENT_IP}"'","ttl":1,"priority":10,"proxied":true}'
    curl -X POST "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
         -H "X-Auth-Email:${CF_API_EMAIL}" \
         -H "X-Auth-Key:${CF_API_KEY}" \
         -H "Content-Type:application/json" \
         --data '{"type":"CNAME","name":"@","content":"'"${CONTENT_CNAME}"'","ttl":1,"priority":10,"proxied":false}'

    curl -X POST "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
         -H "X-Auth-Email:${CF_API_EMAIL}" \
         -H "X-Auth-Key:${CF_API_KEY}" \
         -H "Content-Type:application/json" \
         --data '{"type":"CNAME","name":"www","content":"'"${CONTENT_CNAME}"'","ttl":1,"priority":10,"proxied":false}'

    curl -X POST "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
         -H "X-Auth-Email:${CF_API_EMAIL}" \
         -H "X-Auth-Key:${CF_API_KEY}" \
         -H "Content-Type:application/json" \
         --data '{"type":"CNAME","name":"m","content":"'"${CONTENT_CNAME}"'","ttl":1,"priority":10,"proxied":false}'

    curl -X POST "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
         -H "X-Auth-Email:${CF_API_EMAIL}" \
         -H "X-Auth-Key:${CF_API_KEY}" \
         -H "Content-Type:application/json" \
         --data '{"type":"CNAME","name":"'"${host_head}"'","content":"'"${CONTENT_CNAME_2}"'","ttl":1,"priority":10,"proxied":false}'

    curl -X POST "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
         -H "X-Auth-Email:${CF_API_EMAIL}" \
         -H "X-Auth-Key:${CF_API_KEY}" \
         -H "Content-Type:application/json" \
         --data '{"type":"MX","name":"@","content":"'"${CONTENT_MX}"'","ttl":1,"priority":10,"proxied":false}'

#    curl -X POST "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/dns_records" \
#         -H "X-Auth-Email:${CF_API_EMAIL}" \
#         -H "X-Auth-Key:${CF_API_KEY}" \
#         -H "Content-Type:application/json" \
#         --data '{"type":"CNAME","name":"_acme-challenge","content":"'"${CERTIFICATE}"'","ttl":1,"priority":10,"proxied":false}'

done < $PWD/zone_id.cf




## 始终使用HTTPS设置
## value:off 关闭 on 开启
#
#while read line
#do
#    ZONE_NAME=$(${ECHO} "$line" | awk '{print $1}')
#    ZONE_ID=$(${ECHO} "$line" | awk '{print $2}')
#    curl -X PATCH "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/settings/always_use_https" \
#         -H "X-Auth-Email:${CF_API_EMAIL}" \
#         -H "X-Auth-Key:${CF_API_KEY}" \
#         -H "Content-Type:application/json" \
#         --data '{"id":"always_use_https","value":"on"}'
#done < $PWD/zone_id.cf
