#!/bin/bash

echo -e "\033[32m 请选择CF 账号: 1   2   3   4\033[0m"

read -p "请输入您选择的CF账号:" cad
if [ $cad -eq 1 ];
   then source env/1.env;
elif [ $cad -eq 2 ];
   then source env/2.env;
elif [ $cad -eq 3 ];
   then source env/3.env;
elif [ $cad -eq 4 ];
   then source env/4.env;
elif [ $cad -eq 5 ];
   then source env/5.env;
elif [ $cad -eq 6 ];
   then source env/6.env;
else
  echo "输入错误，退出程序" 
  exit 1
fi


# 获取开启https
while read line
do
	ZONE_ID=$(${ECHO} "$line" | awk '{print $2}')
	curl -X PATCH "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}/settings/always_use_https" \
	-H "X-Auth-Email: ${CF_API_EMAIL}" \
	-H "X-Auth-Key: ${CF_API_KEY}" \
	-H "Content-Type: application/json" \
	--data '{"value":"on"}' | jq .
done < $PWD/zone_id.cf




