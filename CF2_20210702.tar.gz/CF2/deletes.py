#!/usr/bin/env python
#*- coding:utf-8 -*

# 打开文件获取添加域名成功后返回的数据，然后获取到域名的区域ID
# 通过区域ID获取DNS列表

import json
import os
import traceback

# traceback 完整输出报错信息
# str(e) 只给出异常信息，不包括异常信息的类型，如1/0的异常信息
# repr(e) 给出较全的异常信息，包括异常信息的类型，如1/0的异常信息



PWD = os.getcwd()

PWD_GET = PWD+'/get_zone_id.cf'
PWD_ZONE = PWD+'/zone_id.cf'
ERROR_FILE = PWD+'/zone_error.log'


#删除get_zone_id.cf中没有获取到zone_id的域名返回信息
with open(PWD_GET,'r') as r:
    lines=r.readlines()
with open(PWD_GET,'w') as w:
    for l in lines:
       if '{"success":false,"errors":[{"code":1061,"message":' not in l:
          w.write(l) 
