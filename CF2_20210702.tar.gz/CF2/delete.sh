#!/bin/bash


rm -rf *cf
echo -e "\033[32m 请选择CF 账号: 1   2   3   9\033[0m"

read -p "请输入您选择的CF账号:" cad

if [ $cad -eq 1 ];
   then source env/1.env;
elif [ $cad -eq 2 ];
   then source env/2.env; 
elif [ $cad -eq 3 ];
   then source env/3.env;
elif [ $cad -eq 9 ];
   then source env/9.env;
else
  echo "输入错误，退出程序" 
  exit 1
fi


# 获取域名的区域ID
for domain in $(cat $PWD/domains.txt)
do
    curl -X GET "https://api.cloudflare.com/client/v4/zones?name=${domain}" \
         -H "X-Auth-Email: ${CF_API_EMAIL}" \
         -H "X-Auth-Key: ${CF_API_KEY}" \
         -H "Content-Type: application/json" >> $PWD/get_zone_id.cf
    ${ECHO} -e "\n" >> $PWD/get_zone_id.cf
done


# 执行python脚本，过滤出域名的区域ID
$PYTHON $PWD/filter_h_zone_id.py



###通过获取域名的区域ID来删去域名
while read line
do
    ZONE_NAME=$(${ECHO} "$line" | awk '{print $1}')
    ZONE_ID=$(${ECHO} "$line" | awk '{print $2}')
	
	echo -e "\033[32m $ZONE_NAME \033[0m"
    curl -X DELETE "https://api.cloudflare.com/client/v4/zones/${ZONE_ID}" \
         -H "X-Auth-Email:${CF_API_EMAIL}" \
         -H "X-Auth-Key:${CF_API_KEY}" \
         -H "Content-Type:application/json"
	echo -e "\n"
done < $PWD/zone_id.cf
