#!/usr/bin/env python
#*- coding:utf-8 -*

# 打开文件读取cloudflare返回的DNS ID

import json
import os
import demjson

PWD = os.getcwd()

PWD_GET = PWD+'/get_dns_id.cf'
PWD_DNS = PWD+'/dns_id.cf'


# 读取获取DNS ID时返回的字符串，并且循环写入字典，以便于过滤出DNS ID
with open (PWD_GET, "r") as file:
	i = 0
	dict = {}
	for line in file:
		if line.strip  == " " or line == "\n" or line == " \n":
			continue
	#	json_file = demjson(json_string)
#		dict = json.loads(line)
		dict[i] = json.loads(line)
		i+=1


key_list = dict.keys()

for key in key_list:
	list =  dict[key]['result']

    # 一个域名可能有多个DNS记录，cloudflare返回的是一个列表,列表中是一个一个的字典，
    # 一个key-values代表一个DNS记录，所以这里需要遍历列表中的字典
	# 通过取列表的索引值，循环每一个位置的字典
	for i in list:
		with open (PWD_DNS,'a+') as file:
			line = i['name'] + " " + i['id'] + "\n"
			file.writelines(line)
