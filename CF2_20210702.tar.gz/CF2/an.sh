#!/bin/bash
sun=$(wc -l pt.txt | awk '{print $1}')

for ((i=1; i<=$sun; i++))
do
	if [ $i -le $sun ]
	then
		num=$(awk 'NR=="'$i'"{print $1}' pt.txt)
		num2=$(awk 'NR=="'$i'"{print $2}' pt.txt)
		num3=$(cat env/"$num".env | sed -n 23p | awk -F "=" '{print $2}')
		num4=$(awk 'NR=="'$i'"{print $3}' pt.txt)
		host_head=$(awk 'NR=="'$i'"{print $4}' pt.txt)
		head_old=$(cat env/"$num".env | sed -n 25p | awk -F "=" '{print $2}')
		host_record=$(awk 'NR=="'$i'"{print $5}' pt.txt)
		record_old=$(cat env/"$num".env | sed -n 24p | awk -F "=" '{print $2}')
		sed -i "s/$num3/$num2/" env/"$num".env
		sed -i "s/$head_old/$host_head/" env/"$num".env
		sed -i "s/$record_old/$host_record/" env/"$num".env
		if [ "$num4" == "新增" ]
		then

/usr/bin/expect<<EOF
set timeout 3000
spawn bash one.sh
expect {
	"请输入您选择的CF账号" {
		send "$num\r"
	}
}
expect eof
EOF

#/usr/bin/expect<<EOF
#set timeout 3000
#spawn bash yicunzai_one.sh
#expect {
#        "请输入您选择的CF账号" {
#                send "$num\r"
#        }
#}
#expect eof
#EOF

		elif [ "$num4" == "修改" ]
		then
/usr/bin/expect<<EOF
set timeout 3000
spawn bash one.sh
expect {
        "请输入您选择的CF账号" {
                send "$num\r"
        }
}
expect eof
EOF

/usr/bin/expect<<EOF
set timeout 3000
spawn bash yicunzai_one.sh
expect {
        "请输入您选择的CF账号" {
                send "$num\r"
        }
}
expect eof
EOF
		fi
		sum1=$(cat -n domains.txt | wc -l)
		sum2=$(cat -n zone_id.cf | wc -l)

		if [ "$sum1" == "$sum2" ]
		then
			echo "Go!"
		else
			echo "域名未加上!"
			exit
		fi

/usr/bin/expect<<EOF
set timeout 3000
spawn bash zouip_two.sh
expect {
        "请输入您选择的CF账号" {
                send "$num\r"
       	}
}
expect eof
EOF
	fi
done
