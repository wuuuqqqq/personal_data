#!/usr/bin/env python
#*- coding:utf-8 -*

# 打开文件获取添加域名成功后返回的数据，然后获取到域名的区域ID
# 通过区域ID获取DNS列表

import json
import os
import traceback

# traceback 完整输出报错信息
# str(e) 只给出异常信息，不包括异常信息的类型，如1/0的异常信息
# repr(e) 给出较全的异常信息，包括异常信息的类型，如1/0的异常信息



PWD = os.getcwd()

PWD_GET = PWD+'/get_zone_id.cf'
PWD_ZONE = PWD+'/zone_id.cf'
ERROR_FILE = PWD+'/zone_error.log'

    

# 读取添加域名时返回的字符串，并且循环写入字典，以便于过滤出域名的区域ID
with open (PWD_GET,'r') as file:
    i = 0
    j = 0
    dict = {}
    list = []
    for line in file:
        if line.strip  == " " or line == "\n" or line == " \n":
            continue
        try:
            dict[i]=json.loads(line)
            i+=1
        except Exception as e:
            j+=1
            with open (ERROR_FILE,'a+') as file:
                title = "----------\t\t第%d条报错信息\t\t---------"%(j) + "\n"
                # info = "报错信息：" + traceback.format_exc() + "\n"
                info = "报错信息：" + repr(e) + "\n"
                mation = "报错行：" + line + "\n"
                file.writelines(title)
                file.writelines(info)
                file.writelines(mation)
            continue



# 获取所有的key，然后进行循环遍历，获取每个域名的区域ID
keys_list = dict.keys()

for key in keys_list:
    ID=dict[key]['result']['id']
    NAME=dict[key]['result']['name']
    with open (PWD_ZONE,'a+') as file:
        line = NAME + " " + ID + "\n"
        file.writelines(line)
